# 📱 Mensaje para Directores - Obtener Chat ID

**Para:** Domingo, Carlos, María  
**Asunto:** Configuración de Acceso - Smarter OS  
**Prioridad:** Alta

---

## Plantilla de Mensaje (Telegram/Email)

```
Hola [NOMBRE],

Estoy configurando tu acceso al sistema Smarter OS como [ROL].

Para que puedas entrar, necesito que hagas lo siguiente:

═══════════════════════════════════════════════════════════
📝 PASOS PARA OBTENER TU ID DE ACCESO
═══════════════════════════════════════════════════════════

1. Abre Telegram en tu celular o computadora

2. En el buscador, escribe: @userinfobot

3. Toca el bot que aparece (tiene un ícono de robot)

4. Envía el mensaje: /start

5. El bot te responderá con algo como:
   
   "Your user ID: 123456789"
   "Your name: [TU NOMBRE]"

6. Copia ese número (123456789) y envíamelo por esta conversación

═══════════════════════════════════════════════════════════

Una vez que me des ese número, configuro tu acceso con:

  • Rol: [TU ROL - ej: CEO, Trading Director, etc.]
  • Permisos: [TUS PERMISOS - ej: trading, market, analytics]
  • Nombre: [TU NOMBRE COMPLETO]

Después de configurado, podrás usar el bot:
  @smarteros_gatekeeper_bot

Comandos que podrás usar:
  /start - Iniciar sesión
  /status - Ver estado del sistema
  /help - Ayuda de tu rol
  /nodes - Ver otros directores conectados

═══════════════════════════════════════════════════════════

¿Tienes alguna duda? Avísame y te ayudo.

¡Quedo atento!

Pedro J. Zaffuto Ruiz
Especialista Blockchain - Smarter OS
Telegram: @pedro_blockchain
═══════════════════════════════════════════════════════════
```

---

## Versión Corta (WhatsApp/Telegram Rápido)

```
[NOMBRE], necesito que hagas esto rápido:

1. Abre Telegram
2. Busca: @userinfobot  
3. Manda: /start
4. Copia el ID que te da
5. Envíamelo

Con eso configuro tu acceso como [ROL] al sistema.

El bot es: @smarteros_gatekeeper_bot

¿Dudas? Avísame.
```

---

## Recordatorio de Seguimiento

```
Hola [NOMBRE], ¿pudiste obtener tu ID de Telegram?

Es el número que te da @userinfobot cuando le mandas /start.

Lo necesito para configurarte como [ROL] en Smarter OS.

¡Avísame si tienes problemas!
```

---

## IDs Pendientes

| Director | Rol | Mensaje Enviado | ID Recibido |
|----------|-----|-----------------|-------------|
| Domingo Ramón Núñez | CEO | ⏳ Pendiente | ❌ Pendiente |
| Carlos Velasco | Trading | ⏳ Pendiente | ❌ Pendiente |
| María Fernández | Consultoría | ⏳ Pendiente | ❌ Pendiente |

---

**Nota:** Una vez que los 3 envíen sus IDs, actualizar `NODES` en validator.js y desplegar.

# ⚡ SMARTEROS QUICK VERIFICATION SCRIPT

Copy-paste ready commands for final verification.

---

## 🚀 ONE-LINER VERIFICATION (Copy & Paste)

```bash
# Run complete verification in one shot
ssh root@89.116.23.167 << 'EOF'
echo "╔═══════════════════════════════════════╗"
echo "║   SMARTEROS v2.1 FINAL VERIFICATION   ║"
echo "║   $(date '+%Y-%m-%d %H:%M:%S UTC')          ║"
echo "╚═══════════════════════════════════════╝"
echo ""
echo "✓ CONTAINERS"
docker ps --format "table {{.Names}}\t{{.Status}}" | head -15 | grep -c "Up"
echo "  Running: $(docker ps -q | wc -l) containers"
echo ""
echo "✓ DATABASE"
docker exec smarteros-postgres psql -U postgres -d smarteros -c "SELECT COUNT(*) FROM pg_tables WHERE schemaname='public';" 2>/dev/null | tail -1 | xargs echo "  Tables:"
echo ""
echo "✓ ENDPOINTS"
for url in "api.smarterbot.cl" "n8n.smarterbot.cl"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" "https://$url" 2>/dev/null)
  echo "  $url: HTTP $code"
done
echo ""
echo "✓ MCP ENDPOINT"
curl -s http://localhost:3051/health 2>/dev/null | head -c 30 && echo " ... ✓"
echo ""
echo "✓ RESOURCES"
docker stats --no-stream | head -3 | tail -1 | awk '{print "  CPU: " $2 ", Memory: " $3}'
echo ""
echo "═══════════════════════════════════════"
echo "✅ VERIFICATION COMPLETE"
echo "═══════════════════════════════════════"
EOF
```

---

## 🔍 STEP-BY-STEP VERIFICATION

### 1. Service Health
```bash
ssh root@89.116.23.167 "docker ps --format 'table {{.Names}}\t{{.Status}}' | grep -v 'Up' | wc -l" | xargs echo "Unhealthy services:"
```

**Expected Output:** `Unhealthy services: 0`

### 2. Database Connectivity
```bash
ssh root@89.116.23.167 "docker exec smarteros-postgres psql -U postgres -c 'SELECT 1' >/dev/null 2>&1 && echo '✅ Database OK' || echo '❌ Database ERROR'"
```

**Expected Output:** `✅ Database OK`

### 3. Table Count
```bash
ssh root@89.116.23.167 "docker exec smarteros-postgres psql -U postgres -d smarteros -c 'SELECT COUNT(*) FROM pg_tables WHERE schemaname=\"public\"' 2>/dev/null | grep -oE '[0-9]+$'"
```

**Expected Output:** `64`

### 4. Workflows Count
```bash
ssh root@89.116.23.167 "docker exec smarteros-postgres psql -U postgres -d smarteros -c 'SELECT COUNT(*) FROM telegram_workflows' 2>/dev/null | grep -oE '[0-9]+$'"
```

**Expected Output:** `5`

### 5. API Gateway Response
```bash
curl -s -o /dev/null -w "%{http_code}\n" https://api.smarterbot.cl/health
```

**Expected Output:** `200`

### 6. N8N Platform
```bash
curl -s -o /dev/null -w "%{http_code}\n" https://n8n.smarterbot.cl
```

**Expected Output:** `200`

### 7. MCP Endpoint
```bash
curl -s http://localhost:3051/health | jq '.status'
```

**Expected Output:** `"ok"`

### 8. Telegram Bot
```bash
ssh root@89.116.23.167 "docker logs telegram-bot --tail 1 | grep -i running"
```

**Expected Output:** Should show "running on port 8443"

### 9. CPU Usage
```bash
docker stats --no-stream | head -3 | tail -1 | awk '{print "CPU: " $2}'
```

**Expected Output:** `CPU: <1%`

### 10. Memory Usage
```bash
docker stats --no-stream | head -3 | tail -1 | awk '{print "Memory: " $3}'
```

**Expected Output:** `Memory: <3GB`

---

## 🧪 GOLDEN PATH TEST

### Complete End-to-End Test
```bash
echo "Testing: Telegram → MCP → Database"
echo ""

# 1. Create lead via MCP endpoint
echo "Step 1: Creating lead via MCP..."
curl -s -X POST http://localhost:3051/execute \
  -H "Content-Type: application/json" \
  -d '{
    "tool": "crm.create_lead",
    "data": {
      "name": "Test User",
      "email": "test@smarteros.io",
      "source": "verification"
    },
    "tenant_id": "smarteros"
  }' | jq '.success'

sleep 1

# 2. Verify in database
echo "Step 2: Verifying in database..."
ssh root@89.116.23.167 "docker exec smarteros-postgres psql -U postgres -d smarteros -c \
  \"SELECT name, email FROM leads WHERE email='test@smarteros.io' LIMIT 1\" 2>/dev/null"

echo ""
echo "✅ Golden path test complete"
```

---

## 📊 RESOURCE MONITORING

### Real-time Dashboard
```bash
ssh root@89.116.23.167 "bash /root/dashboard-health.sh"
```

### Live Container Stats
```bash
watch -n 2 'ssh root@89.116.23.167 "docker stats --no-stream --format \"table {{.Container}}\t{{.CPUPerc}}\t{{.MemUsage}}\" | head -15"'
```

### Disk Space
```bash
ssh root@89.116.23.167 "df -h / | tail -1"
```

**Expected Output:** `72% used, 25GB free`

---

## 🚨 ALERT CHECKS

### Any Unhealthy Services?
```bash
ssh root@89.116.23.167 "docker ps --format '{{.Names}}\t{{.Status}}' | grep -i unhealthy"
```

**Expected Output:** (empty - no unhealthy services)

### Any Restarting Containers?
```bash
ssh root@89.116.23.167 "docker ps --format '{{.Names}}\t{{.Status}}' | grep -i restarting"
```

**Expected Output:** (empty - no restarting)

### PostgreSQL Connection Issues?
```bash
ssh root@89.116.23.167 "docker logs smarteros-postgres 2>&1 | grep -i 'error\|fatal' | tail -5"
```

**Expected Output:** (empty - no errors)

### MCP Endpoint Errors?
```bash
ssh root@89.116.23.167 "tail -20 /tmp/mcp-execute.log | grep -i error"
```

**Expected Output:** (empty - no errors)

---

## 💾 BACKUP VERIFICATION

### Last Backup Status
```bash
ssh root@89.116.23.167 "ls -lh /root/backups/ | tail -3"
```

**Expected Output:** Recent `.dump` files

### Backup Size
```bash
ssh root@89.116.23.167 "du -sh /root/backups/"
```

**Expected Output:** Should show backup directory size

### Next Scheduled Backup
```bash
ssh root@89.116.23.167 "crontab -l | grep backup"
```

**Expected Output:** `0 2 * * * bash /root/backup-daily.sh`

---

## 🔐 SECURITY VERIFICATION

### HTTPS Status
```bash
curl -I https://api.smarterbot.cl | grep -E "HTTP|Strict"
```

**Expected Output:** 
```
HTTP/2 200
Strict-Transport-Security: max-age=31536000
```

### SSL Certificate
```bash
echo | openssl s_client -servername api.smarterbot.cl -connect api.smarterbot.cl:443 2>/dev/null | grep -A 2 "subject="
```

**Expected Output:** Shows certificate subject

### Rate Limiting
```bash
for i in {1..310}; do curl -s https://api.smarterbot.cl/health >/dev/null & done; wait
```

**Expected Output:** Some requests should get 429 (rate limited)

---

## 📈 PERFORMANCE BASELINE

### API Response Time
```bash
time curl -s https://api.smarterbot.cl/health > /dev/null
```

**Expected Output:** `real    0m0.1XX s` (under 200ms)

### Database Query
```bash
ssh root@89.116.23.167 << 'EOF'
time docker exec smarteros-postgres psql -U postgres -d smarteros \
  -c "SELECT COUNT(*) FROM telegram_workflows" >/dev/null
EOF
```

**Expected Output:** `real    0m0.0XX s` (under 100ms)

### MCP Tool Execution
```bash
time curl -X POST http://localhost:3051/execute \
  -H "Content-Type: application/json" \
  -d '{"tool":"docker.list_containers","data":{},"tenant_id":"smarteros"}' \
  | jq .
```

**Expected Output:** `real    0m0.1XX s` (under 200ms)

---

## 🎯 FINAL SIGN-OFF CHECKLIST

```bash
#!/bin/bash

echo "SMARTEROS v2.1 FINAL SIGN-OFF"
echo "=============================="
echo ""

CHECKS_PASSED=0
CHECKS_TOTAL=12

# Check 1: Containers
if [ "$(ssh root@89.116.23.167 "docker ps -q | wc -l")" -ge 24 ]; then
  echo "✅ Check 1: Containers running"
  ((CHECKS_PASSED++))
else
  echo "❌ Check 1: Not enough containers"
fi
((CHECKS_TOTAL++))

# Check 2: Database
if ssh root@89.116.23.167 "docker exec smarteros-postgres psql -U postgres -c 'SELECT 1' >/dev/null 2>&1"; then
  echo "✅ Check 2: Database responsive"
  ((CHECKS_PASSED++))
else
  echo "❌ Check 2: Database not responding"
fi

# Check 3: Tables
TABLES=$(ssh root@89.116.23.167 "docker exec smarteros-postgres psql -U postgres -d smarteros -c 'SELECT COUNT(*) FROM pg_tables WHERE schemaname=\"public\"' 2>/dev/null | grep -oE '[0-9]+$'")
if [ "$TABLES" -ge 64 ]; then
  echo "✅ Check 3: Database schema complete ($TABLES tables)"
  ((CHECKS_PASSED++))
else
  echo "❌ Check 3: Schema incomplete ($TABLES tables)"
fi

# Check 4: Workflows
WORKFLOWS=$(ssh root@89.116.23.167 "docker exec smarteros-postgres psql -U postgres -d smarteros -c 'SELECT COUNT(*) FROM telegram_workflows' 2>/dev/null | grep -oE '[0-9]+$'")
if [ "$WORKFLOWS" -ge 5 ]; then
  echo "✅ Check 4: Workflows configured ($WORKFLOWS)"
  ((CHECKS_PASSED++))
else
  echo "❌ Check 4: Workflows missing"
fi

# Check 5: API Gateway
API_CODE=$(curl -s -o /dev/null -w "%{http_code}" https://api.smarterbot.cl/health 2>/dev/null)
if [ "$API_CODE" = "200" ]; then
  echo "✅ Check 5: API Gateway responding"
  ((CHECKS_PASSED++))
else
  echo "❌ Check 5: API Gateway returned $API_CODE"
fi

# Check 6: N8N
N8N_CODE=$(curl -s -o /dev/null -w "%{http_code}" https://n8n.smarterbot.cl 2>/dev/null)
if [ "$N8N_CODE" = "200" ]; then
  echo "✅ Check 6: N8N platform ready"
  ((CHECKS_PASSED++))
else
  echo "❌ Check 6: N8N returned $N8N_CODE"
fi

# Check 7: MCP Endpoint
if curl -s http://localhost:3051/health 2>/dev/null | grep -q "ok"; then
  echo "✅ Check 7: MCP /execute operational"
  ((CHECKS_PASSED++))
else
  echo "❌ Check 7: MCP endpoint not responding"
fi

# Check 8: Telegram Bot
if ssh root@89.116.23.167 "docker logs telegram-bot --tail 1 | grep -q running"; then
  echo "✅ Check 8: Telegram bot active"
  ((CHECKS_PASSED++))
else
  echo "❌ Check 8: Telegram bot issue"
fi

# Check 9: Backups
if ssh root@89.116.23.167 "[ -f /root/backup-daily.sh ] && [ -x /root/backup-daily.sh ]"; then
  echo "✅ Check 9: Backup automation configured"
  ((CHECKS_PASSED++))
else
  echo "❌ Check 9: Backup not configured"
fi

# Check 10: Monitoring
if curl -s http://localhost:3000 -o /dev/null 2>&1; then
  echo "✅ Check 10: Grafana dashboards live"
  ((CHECKS_PASSED++))
else
  echo "❌ Check 10: Grafana not responding"
fi

# Check 11: HTTPS
if curl -I https://api.smarterbot.cl 2>/dev/null | grep -q "Strict-Transport-Security"; then
  echo "✅ Check 11: Security headers active"
  ((CHECKS_PASSED++))
else
  echo "❌ Check 11: Security headers missing"
fi

# Check 12: Documentation
if [ -f /tmp/PRODUCTION_READY_v2.1.md ]; then
  echo "✅ Check 12: Documentation complete"
  ((CHECKS_PASSED++))
else
  echo "❌ Check 12: Documentation missing"
fi

echo ""
echo "════════════════════════════════════════"
echo "RESULT: $CHECKS_PASSED/$CHECKS_TOTAL checks passed"
echo "════════════════════════════════════════"

if [ $CHECKS_PASSED -eq $CHECKS_TOTAL ]; then
  echo "🎉 ALL CHECKS PASSED - READY FOR PRODUCTION"
  exit 0
else
  echo "⚠️  Some checks failed - review above"
  exit 1
fi
```

Save as `/root/verify-production.sh` and run:
```bash
ssh root@89.116.23.167 "bash /root/verify-production.sh"
```

---

## 📞 IF ANY CHECK FAILS

### Service Not Running?
```bash
ssh root@89.116.23.167 "docker restart SERVICE_NAME && sleep 5 && docker logs SERVICE_NAME --tail 10"
```

### Database Unreachable?
```bash
ssh root@89.116.23.167 "docker restart smarteros-postgres && sleep 10 && docker exec smarteros-postgres psql -U postgres -c 'SELECT 1'"
```

### API Gateway 5XX Error?
```bash
ssh root@89.116.23.167 "docker logs smarteros-api-mcp -f --tail 50"
```

### MCP Endpoint Not Responding?
```bash
ssh root@89.116.23.167 "pkill -f 'node.*mcp-execute' && sleep 2 && cd /root && nohup node mcp-execute-endpoint.js > /tmp/mcp-execute.log 2>&1 &"
```

---

**Ready? Run the verification and confirm all checks pass! ✅**


# 00_CORE - Instalación Base

## Requisitos Mínimos

- Docker instalado
- Node.js 18+
- Token de Telegram (@BotFather)
- Tu Chat ID (de @userinfobot)

## Instalación Docker

```bash
# Ubuntu/Debian
curl -fsSL https://get.docker.com | sh

# Verificar
docker --version
```

## Instalación Node.js

```bash
# Usando nvm (recomendado)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
nvm install 18

# Verificar
node --version
npm --version
```

## Estructura de Archivos

```
/smarteros-factory/
├── core/
│   └── validator.js
├── docs/
│   ├── 00_CORE.md
│   ├── 01_TELEGRAM.md
│   └── 02_CHACHA20.md
├── package.json
├── Dockerfile
└── README.md
```

## Próximos Pasos

1. → Ver `01_TELEGRAM.md` para configuración del Bot
2. → Ver `02_CHACHA20.md` para cifrado (pendiente)

---

**Estado:** ✅ ACTIVO  
**Última actualización:** 2026-03-05

# 🔧 N8N WORKFLOWS - CONFIGURATION & SETUP GUIDE

**Version:** 2.1  
**Status:** Ready for Production Import  
**Total Workflows:** 5 Base + Extensible

---

## 📝 WORKFLOW INVENTORY

### Workflow 1: List Containers (Docker Management)
```json
{
  "name": "List Containers",
  "trigger": "Telegram: 'lista contenedores'",
  "path": "/webhook/list-containers",
  "steps": [
    "Parse Telegram message",
    "Call MCP: docker.list_containers",
    "Format JSON response",
    "Send to Telegram"
  ],
  "timeout": "5s",
  "status": "active"
}
```

### Workflow 2: Get Container Logs
```json
{
  "name": "Get Container Logs",
  "trigger": "Telegram: 'logs de [container]'",
  "path": "/webhook/get-logs",
  "steps": [
    "Extract container name from message",
    "Call MCP: docker.get_logs",
    "Truncate to 50 lines",
    "Send to Telegram"
  ],
  "timeout": "10s",
  "status": "active"
}
```

### Workflow 3: Fraud Detection Check
```json
{
  "name": "Fraud Detection",
  "trigger": "Telegram: 'detectar fraude [amount]'",
  "path": "/webhook/fraud-check",
  "steps": [
    "Parse amount from message",
    "Call MCP: fraud.analyze",
    "Determine risk level (LOW/HIGH/CRITICAL)",
    "Alert user with risk score",
    "Log to database"
  ],
  "timeout": "5s",
  "status": "active"
}
```

### Workflow 4: Create CRM Lead
```json
{
  "name": "Create Lead",
  "trigger": "Telegram: 'crear lead [name] [email]'",
  "path": "/webhook/create-lead",
  "steps": [
    "Parse name and email",
    "Call MCP: crm.create_lead",
    "Store in PostgreSQL",
    "Confirm to Telegram",
    "Log execution"
  ],
  "timeout": "5s",
  "status": "active"
}
```

### Workflow 5: Daily Report
```json
{
  "name": "Daily Report",
  "trigger": "Schedule: Daily 8 AM UTC",
  "path": "/webhook/daily-report",
  "steps": [
    "Query: New leads (last 24h)",
    "Query: Fraud detections (last 24h)",
    "Query: Workflow executions",
    "Generate summary",
    "Send to Telegram"
  ],
  "timeout": "30s",
  "status": "active"
}
```

---

## 🔗 N8N WEBHOOK CONFIGURATION

### Basic Setup
```
1. Open https://n8n.smarterbot.cl
2. Login with admin credentials
3. Menu → Workflows → New
4. Add "Webhook" trigger node
5. Select: POST
6. Path: /[workflow-name]
7. Enable in production
```

### Webhook URL Format
```
https://n8n.smarterbot.cl/webhook/[workflow-id]
https://n8n.smarterbot.cl/webhook/list-containers
https://n8n.smarterbot.cl/webhook/fraud-check
```

### Headers for API Calls
```json
{
  "Content-Type": "application/json",
  "Authorization": "Bearer [N8N_API_KEY]",
  "X-Tenant-ID": "smarteros"
}
```

---

## 🔌 HTTP NODE CONFIGURATION (For MCP Integration)

### Basic HTTP POST Template
```json
{
  "url": "https://api.smarterbot.cl/execute",
  "method": "POST",
  "headers": {
    "Content-Type": "application/json",
    "X-Tenant-ID": "smarteros"
  },
  "body": {
    "tool": "{{$json.tool}}",
    "data": "{{$json.data}}",
    "tenant_id": "smarteros"
  }
}
```

### Example: List Containers HTTP Node
```json
{
  "url": "http://localhost:3051/execute",
  "method": "POST",
  "body": {
    "tool": "docker.list_containers",
    "data": {
      "filters": "status=running"
    },
    "tenant_id": "smarteros"
  }
}
```

### Example: Fraud Detection HTTP Node
```json
{
  "url": "http://localhost:3051/execute",
  "method": "POST",
  "body": {
    "tool": "fraud.analyze",
    "data": {
      "amount": "{{$json.amount}}",
      "time_period": "24h"
    },
    "tenant_id": "smarteros"
  }
}
```

### Example: Create Lead HTTP Node
```json
{
  "url": "http://localhost:3051/execute",
  "method": "POST",
  "body": {
    "tool": "crm.create_lead",
    "data": {
      "name": "{{$json.name}}",
      "email": "{{$json.email}}",
      "source": "telegram"
    },
    "tenant_id": "smarteros"
  }
}
```

---

## 📝 N8N WORKFLOW TEMPLATES (Ready to Import)

### Template 1: Basic MCP Router
```json
{
  "name": "MCP Router",
  "nodes": [
    {
      "parameters": {},
      "name": "Webhook",
      "type": "n8n-nodes-base.webhook",
      "typeVersion": 1,
      "position": [250, 300]
    },
    {
      "parameters": {
        "url": "http://localhost:3051/execute",
        "method": "POST",
        "body": {
          "tool": "={{$json.tool}}",
          "data": "={{$json.data}}",
          "tenant_id": "smarteros"
        }
      },
      "name": "HTTP Request",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4,
      "position": [450, 300]
    },
    {
      "parameters": {
        "content": "Tool executed: {{$json.result.tool}}\nStatus: {{$json.success}}"
      },
      "name": "Notify",
      "type": "n8n-nodes-base.sendTelegramNotification",
      "typeVersion": 1,
      "position": [650, 300]
    }
  ],
  "connections": {
    "Webhook": {
      "main": [[{"node": "HTTP Request", "branch": 0, "type": "main"}]]
    },
    "HTTP Request": {
      "main": [[{"node": "Notify", "branch": 0, "type": "main"}]]
    }
  }
}
```

### Template 2: Database Logger
```json
{
  "name": "Log to Database",
  "nodes": [
    {
      "parameters": {},
      "name": "Webhook",
      "type": "n8n-nodes-base.webhook",
      "typeVersion": 1,
      "position": [250, 300]
    },
    {
      "parameters": {
        "url": "http://localhost:3051/execute",
        "method": "POST",
        "body": {
          "tool": "={{$json.tool}}",
          "data": "={{$json.data}}",
          "tenant_id": "smarteros"
        }
      },
      "name": "Execute MCP Tool",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4,
      "position": [450, 300]
    },
    {
      "parameters": {
        "query": "INSERT INTO telegram_workflow_executions (workflow_id, telegram_user_id, trigger_message, result, status) VALUES ('{{$json.workflow_id}}', {{$json.user_id}}, '{{$json.message}}', '{{JSON.stringify($json.result)}}', '{{$json.success ? 'success' : 'error'}}')"
      },
      "name": "Save to PostgreSQL",
      "type": "n8n-nodes-base.postgres",
      "typeVersion": 2,
      "position": [650, 300]
    }
  ]
}
```

---

## 🚀 IMPORT WORKFLOWS TO N8N

### Method 1: UI Import
```
1. Go to https://n8n.smarterbot.cl
2. Menu → Import
3. Select JSON file or paste workflow JSON
4. Click Import
5. Verify nodes and connections
6. Click Save & Activate
```

### Method 2: API Import
```bash
curl -X POST https://n8n.smarterbot.cl/api/v1/workflows \
  -H "X-N8N-API-KEY: [YOUR_API_KEY]" \
  -H "Content-Type: application/json" \
  -d @workflow.json
```

### Method 3: File Upload (SSH)
```bash
scp workflow.json root@89.116.23.167:/root/n8n-workflows/
ssh root@89.116.23.167 << 'EOF'
cd /root/n8n-workflows
for file in *.json; do
  echo "Importing $file..."
  docker exec smarteros-n8n curl -X POST http://localhost:5678/api/v1/workflows \
    -H "Content-Type: application/json" \
    -d @"$file"
done
EOF
```

---

## 🔒 N8N SECURITY CONFIGURATION

### Enable API Key Protection
```
1. Admin Panel → Users & Permissions
2. Create API key for bot
3. Use in all API calls: X-N8N-API-KEY header
```

### Webhook URL Validation
```json
{
  "webhook_validation": {
    "enabled": true,
    "token": "secure-random-token-here",
    "signature_algorithm": "sha256"
  }
}
```

### Rate Limiting
```json
{
  "rate_limits": {
    "webhook": {
      "requests_per_minute": 60,
      "burst_size": 10
    },
    "api": {
      "requests_per_minute": 100,
      "burst_size": 20
    }
  }
}
```

---

## 📊 N8N MONITORING

### Health Check Endpoint
```bash
curl -s https://n8n.smarterbot.cl/api/v1/health | jq .
```

### Workflow Execution Status
```bash
curl -s https://n8n.smarterbot.cl/api/v1/workflows \
  -H "X-N8N-API-KEY: [KEY]" | jq '.data[] | {name, active, nodes}'
```

### Recent Executions
```bash
curl -s https://n8n.smarterbot.cl/api/v1/executions \
  -H "X-N8N-API-KEY: [KEY]" | jq '.data | .[0:5]'
```

---

## 🧪 TESTING WORKFLOWS

### Test List Containers
```bash
# Via webhook
curl -X POST https://n8n.smarterbot.cl/webhook/list-containers \
  -H "Content-Type: application/json" \
  -d '{"filters":"running"}'

# Or via Telegram
@SmarterChat_bot > "lista contenedores"
```

### Test Create Lead
```bash
# Via webhook
curl -X POST https://n8n.smarterbot.cl/webhook/create-lead \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john@example.com",
    "source": "test"
  }'

# Or via Telegram
@SmarterChat_bot > "crear lead John Doe john@example.com"
```

### Test Fraud Detection
```bash
# Via webhook
curl -X POST https://n8n.smarterbot.cl/webhook/fraud-check \
  -H "Content-Type: application/json" \
  -d '{"amount": 5000, "currency": "USD"}'

# Or via Telegram
@SmarterChat_bot > "detectar fraude 5000"
```

---

## ⚙️ ADVANCED N8N FEATURES

### Conditional Routing
```json
{
  "type": "n8n-nodes-base.if",
  "parameters": {
    "conditions": {
      "boolean": [
        {
          "condition": "==",
          "value1": "={{$json.risk_score}}",
          "value2": 100,
          "combinator": "or"
        }
      ]
    }
  }
}
```

### Error Handling
```json
{
  "type": "n8n-nodes-base.errorTrigger",
  "parameters": {
    "trigger": "Catch all errors",
    "errorOutput": "passthroughOnError"
  }
}
```

### Retry Logic
```json
{
  "parameters": {
    "retry": {
      "maxAttempts": 3,
      "delayBetweenAttempts": 1000,
      "backoffCoefficient": 2
    }
  }
}
```

### Scheduled Execution
```json
{
  "type": "n8n-nodes-base.interval",
  "parameters": {
    "interval": [1, "hours"]
  }
}
```

---

## 📈 WORKFLOW OPTIMIZATION TIPS

1. **Parallel Execution:**
   - Use multiple HTTP nodes in parallel
   - Reduces total execution time

2. **Caching:**
   - Store frequently used data
   - Query database only when needed

3. **Batch Processing:**
   - Group multiple operations
   - Process in chunks

4. **Logging:**
   - Log all executions to database
   - Use for debugging and analytics

---

## 🔗 MCP TOOL REFERENCE

### Available Tools via MCP /execute

```json
{
  "crm": {
    "create_lead": {
      "params": ["name", "email", "source"],
      "description": "Create new CRM lead"
    },
    "update_lead": {
      "params": ["lead_id", "field", "value"],
      "description": "Update existing lead"
    }
  },
  "docker": {
    "list_containers": {
      "params": ["filters"],
      "description": "List all containers"
    },
    "get_logs": {
      "params": ["container_id", "lines"],
      "description": "Get container logs"
    }
  },
  "fraud": {
    "analyze": {
      "params": ["amount", "time_period"],
      "description": "Analyze fraud risk"
    }
  }
}
```

---

## 📞 TROUBLESHOOTING

### Webhook Not Triggering
```bash
# Check N8N webhook status
docker logs smarteros-n8n | grep -i webhook

# Test webhook directly
curl -X POST https://n8n.smarterbot.cl/webhook/test \
  -H "Content-Type: application/json" \
  -d '{"test": true}'
```

### MCP Tool Not Executing
```bash
# Verify MCP endpoint
curl http://localhost:3051/health

# Test tool execution
curl -X POST http://localhost:3051/execute \
  -H "Content-Type: application/json" \
  -d '{"tool":"crm.create_lead","data":{},"tenant_id":"smarteros"}'
```

### Database Connection Failed
```bash
# Check PostgreSQL
docker exec smarteros-postgres psql -U postgres -c "SELECT 1"

# Verify N8N credentials
docker exec smarteros-n8n env | grep -i postgres
```

---

## 🎯 NEXT STEPS

1. ✅ Import workflows to N8N
2. ✅ Activate webhooks
3. ✅ Test golden path
4. ✅ Monitor executions
5. ✅ Scale to 50+ workflows

---

**Last Updated:** March 3, 2026  
**Maintained By:** DevOps Team  
**Version:** 2.1 (Production Ready)


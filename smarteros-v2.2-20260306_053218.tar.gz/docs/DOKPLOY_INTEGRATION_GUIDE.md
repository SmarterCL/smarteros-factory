# 🚀 SMARTEROS + DOKPLOY INTEGRATION GUIDE

**Date:** March 6, 2026  
**Status:** Integration Phase  
**Objective:** Unified deployment management via Dokploy

---

## 📊 CURRENT STATE ANALYSIS

### Dokploy Status
- **Service:** ✅ Running (healthy)
- **Port:** 3000 (internal)
- **Database:** PostgreSQL 16 (dokploy-db)
- **Cache:** Redis 7 (dokploy-redis)
- **Uptime:** 3+ days
- **Auth:** Requires API key/token

### SmartermOS Current Deployment
- **Location:** VPS 89.116.23.167
- **Services:** 25 containers
- **Database:** PostgreSQL 17 (smarteros)
- **Orchestration:** Docker Compose + manual
- **CI/CD:** None (manual deployment)

---

## 🎯 INTEGRATION OBJECTIVES

### Phase 1: Setup Dokploy for SmarterOS (This Week)
1. Create Dokploy projects for each service
2. Setup Git repository integration
3. Configure automated deployments
4. Setup monitoring & alerts

### Phase 2: Migrate to Dokploy Management (Next Week)
1. Import existing services into Dokploy
2. Setup CI/CD pipelines
3. Enable auto-scaling
4. Configure rollback strategies

### Phase 3: Multi-Environment (Month 2)
1. Development environment
2. Staging environment
3. Production environment
4. Blue-green deployments

---

## 🔧 DOKPLOY SETUP FOR SMARTEROS

### Step 1: Access Dokploy Dashboard
```
URL: http://localhost:3000
First-time setup: Register admin account
```

### Step 2: Create Dokploy Projects

```bash
# API credentials setup (after admin account created)
DOKPLOY_API_URL="http://localhost:3000/api"
DOKPLOY_AUTH_TOKEN="[generate in dashboard]"

# Create project for SmartermOS
curl -X POST "$DOKPLOY_API_URL/projects" \
  -H "Authorization: Bearer $DOKPLOY_AUTH_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "smarteros-prod",
    "description": "Production fraud detection platform",
    "team_id": 1
  }'
```

### Step 3: Connect Git Repository

```
1. Go to Dokploy Dashboard
2. Projects → smarteros-prod
3. Add Git Repository
4. URL: https://github.com/[org]/smarteros (or your repo)
5. Branch: main (or production)
6. Deploy trigger: Auto on push
```

### Step 4: Create Application Definitions

#### Application 1: API Gateway
```yaml
name: smarteros-api-mcp
project: smarteros-prod
image: smarteros-api-mcp:latest
port: 3002
environment:
  - MCP_MODE=governed
  - RATE_LIMIT_RPM=300
  - DATABASE_URL=postgresql://user:pass@smarteros-postgres:5432/smarteros
resources:
  cpu: 1000m
  memory: 512Mi
replicas: 2  # Can scale horizontally
healthcheck: /health
```

#### Application 2: N8N
```yaml
name: smarteros-n8n
project: smarteros-prod
image: n8n:latest
port: 5678
volumes:
  - n8n_data:/home/node/.n8n
environment:
  - DB_HOST=smarteros-postgres
  - DB_NAME=smarteros_n8n
resources:
  cpu: 1000m
  memory: 1024Mi
replicas: 1
healthcheck: /api/v1/health
```

#### Application 3: Telegram Bot
```yaml
name: smarteros-telegram-bot
project: smarteros-prod
image: smarteros-telegram:latest
port: 8443
environment:
  - TELEGRAM_TOKEN=[from env]
  - MCP_ENDPOINT=http://smarteros-mcp-execute:3051
resources:
  cpu: 500m
  memory: 256Mi
replicas: 1
```

#### Application 4: MCP /execute Router
```yaml
name: smarteros-mcp-execute
project: smarteros-prod
build:
  context: ./services/mcp-execute
  dockerfile: Dockerfile
port: 3051
environment:
  - DATABASE_URL=postgresql://...
  - LOG_LEVEL=info
resources:
  cpu: 500m
  memory: 512Mi
replicas: 1
```

---

## 📦 DOCKER COMPOSE → DOKPLOY MIGRATION

### Create docker-compose.yml for Dokploy
```yaml
version: '3.9'

services:
  smarteros-postgres:
    image: postgres:17.6-alpine
    ports:
      - "5433:5432"
    environment:
      POSTGRES_DB: smarteros
      POSTGRES_USER: smarteros
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U smarteros"]
      interval: 10s
      timeout: 5s
      retries: 5

  smarteros-api-mcp:
    image: smarteros-api-mcp:latest
    ports:
      - "3002:3000"
    environment:
      DATABASE_URL: postgresql://smarteros:${DB_PASSWORD}@smarteros-postgres:5432/smarteros
      MCP_MODE: governed
      RATE_LIMIT_RPM: 300
    depends_on:
      smarteros-postgres:
        condition: service_healthy
    deploy:
      replicas: 2
      resources:
        limits:
          cpus: '1'
          memory: 512M

  smarteros-n8n:
    image: n8n:latest
    ports:
      - "5678:5678"
    environment:
      DB_HOST: smarteros-postgres
      DB_NAME: smarteros_n8n
      DB_USER: smarteros
      DB_PASSWORD: ${DB_PASSWORD}
    volumes:
      - n8n_data:/home/node/.n8n
    depends_on:
      - smarteros-postgres

  smarteros-mcp-execute:
    build: ./services/mcp-execute
    ports:
      - "3051:3051"
    environment:
      DATABASE_URL: postgresql://smarteros:${DB_PASSWORD}@smarteros-postgres:5432/smarteros
      LOG_LEVEL: info
    depends_on:
      - smarteros-postgres

  telegram-bot:
    image: smarteros-telegram:latest
    ports:
      - "8443:8443"
    environment:
      TELEGRAM_TOKEN: ${TELEGRAM_TOKEN}
      MCP_ENDPOINT: http://smarteros-mcp-execute:3051
      DATABASE_URL: postgresql://smarteros:${DB_PASSWORD}@smarteros-postgres:5432/smarteros
    depends_on:
      - smarteros-postgres
      - smarteros-mcp-execute

  caddy:
    image: caddy:latest
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./config/Caddyfile:/etc/caddy/Caddyfile
      - caddy_data:/data
      - caddy_config:/config
    environment:
      ACME_AGREE: "true"

volumes:
  postgres_data:
  n8n_data:
  caddy_data:
  caddy_config:

networks:
  default:
    name: smarteros-main
```

---

## 🔄 CI/CD PIPELINE SETUP

### GitHub Actions Workflow Example
```yaml
name: Deploy SmartermOS

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Build & Push to Registry
        run: |
          docker build -t smarteros-api-mcp:${{ github.sha }} ./services/api
          docker push registry.smarterbot.cl/smarteros-api-mcp:${{ github.sha }}
      
      - name: Deploy via Dokploy
        run: |
          curl -X POST http://dokploy.smarterbot.cl/api/deployments \
            -H "Authorization: Bearer ${{ secrets.DOKPLOY_TOKEN }}" \
            -H "Content-Type: application/json" \
            -d '{
              "service": "smarteros-api-mcp",
              "image": "smarteros-api-mcp:${{ github.sha }}"
            }'
      
      - name: Run Tests
        run: |
          docker-compose -f docker-compose.test.yml up --abort-on-container-exit
      
      - name: Smoke Test
        run: |
          sleep 30
          curl -f http://localhost:3051/health
```

---

## 📊 DOKPLOY MONITORING INTEGRATION

### Setup Prometheus Scraping
```yaml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'smarteros-services'
    static_configs:
      - targets: ['localhost:9090']
    metrics_path: '/metrics'

  - job_name: 'docker-containers'
    static_configs:
      - targets: ['localhost:9100']
```

### Dokploy Health Checks
```bash
# Check all services via Dokploy
curl -s http://localhost:3000/api/deployments/health \
  -H "Authorization: Bearer $DOKPLOY_TOKEN" | jq '.services[] | {name, status, uptime}'
```

---

## 🚀 DEPLOYMENT STRATEGIES

### Blue-Green Deployment
```bash
# Deploy new version to "green" environment
dokploy deploy smarteros-api-mcp:v2.1 --environment green

# Run tests against green
./tests/integration-tests.sh green

# Switch traffic to green
dokploy switch smarteros-api-mcp --from blue --to green

# Keep blue as rollback
```

### Canary Deployment
```bash
# Deploy to 10% of replicas first
dokploy canary smarteros-api-mcp \
  --percentage 10 \
  --image smarteros-api-mcp:v2.1

# Monitor metrics
watch 'curl -s http://localhost:9090/metrics | grep api_errors'

# Gradually increase to 100%
dokploy canary smarteros-api-mcp --percentage 50
dokploy canary smarteros-api-mcp --percentage 100
```

### Rolling Update
```bash
# Default strategy: replace 1 at a time
dokploy deploy smarteros-api-mcp:v2.1 \
  --strategy rolling \
  --max-surge 1 \
  --max-unavailable 0
```

---

## 📈 SCALING CONFIGURATION

### Horizontal Pod Autoscaling (via Dokploy)
```yaml
autoscaling:
  enabled: true
  min_replicas: 2
  max_replicas: 10
  metrics:
    - type: cpu
      target: 70%
    - type: memory
      target: 80%
    - type: http_requests
      target: 1000  # requests per second
```

### Resource Limits
```yaml
resources:
  requests:
    cpu: 500m
    memory: 512Mi
  limits:
    cpu: 1000m
    memory: 1024Mi
```

---

## 🔐 SECRETS MANAGEMENT

### Store Secrets in Dokploy Vault
```bash
# Add secret
dokploy secrets set TELEGRAM_TOKEN \
  -v "$(cat /root/.telegram_token)" \
  --project smarteros-prod

# Use in deployment
environment:
  - TELEGRAM_TOKEN=${TELEGRAM_TOKEN}
  - DATABASE_PASSWORD=${DB_PASSWORD}
  - API_KEY=${API_KEY}
```

### Rotation Policy
```yaml
secrets:
  rotation:
    enabled: true
    interval: 90  # days
    notification_email: ops@smarterbot.cl
```

---

## 📊 DOCKER COMPOSE → DOKPLOY MIGRATION CHECKLIST

- [ ] Create Dokploy account & projects
- [ ] Connect Git repository
- [ ] Create application definitions for each service
- [ ] Setup environment variables & secrets
- [ ] Configure health checks
- [ ] Setup resource limits
- [ ] Create deployment pipeline (GitHub Actions)
- [ ] Setup monitoring & alerts
- [ ] Test deployment in staging
- [ ] Plan production migration
- [ ] Execute blue-green deployment
- [ ] Verify rollback procedure

---

## 🔄 ROLLBACK PROCEDURE

### Quick Rollback (if issues detected)
```bash
# Automatic: Dokploy detects health check failures
dokploy rollback smarteros-api-mcp --to previous

# Manual: Rollback to specific version
dokploy rollback smarteros-api-mcp --to v2.0

# Check rollback status
dokploy deployments status smarteros-api-mcp
```

### Database Rollback (if schema changes)
```bash
# Restore from backup taken before deployment
docker exec -i smarteros-postgres pg_restore -U smarteros -d smarteros < backup_pre_migration.dump

# Verify data integrity
docker exec smarteros-postgres psql -U smarteros -d smarteros -c "SELECT COUNT(*) FROM telegram_workflows;"
```

---

## 🎯 BENEFITS OF DOKPLOY INTEGRATION

✅ **Automated Deployments**
- Git push → automatic deployment
- No manual docker commands

✅ **High Availability**
- Multiple replicas
- Auto-restart on failure
- Load balancing

✅ **Monitoring & Alerts**
- Health checks
- Metric collection
- Email/Slack alerts

✅ **Scaling**
- Horizontal scaling (add replicas)
- Auto-scaling based on metrics
- Resource limits

✅ **Multi-Environment**
- Dev, staging, production
- Easy environment promotion
- Configuration management

✅ **Version Control**
- All configs in Git
- Audit trail
- Easy rollbacks

---

## 📅 IMPLEMENTATION TIMELINE

### Week 1: Setup & Configuration
- [ ] Day 1-2: Dokploy setup, projects created
- [ ] Day 3-4: Application definitions, secrets
- [ ] Day 5: Staging deployment test

### Week 2: CI/CD Pipeline
- [ ] Day 1-2: GitHub Actions workflow
- [ ] Day 3-4: Test automation
- [ ] Day 5: Production migration plan

### Week 3: Production Migration
- [ ] Day 1-2: Blue-green setup
- [ ] Day 3: Cutover (switch traffic)
- [ ] Day 4-5: Monitor & optimize

---

## 💡 BEST PRACTICES

1. **Always test in staging first**
   ```bash
   dokploy deploy --environment staging --image smarteros-api-mcp:test
   ```

2. **Monitor deployment metrics**
   ```bash
   watch 'curl -s http://localhost:9090/metrics | grep deployment'
   ```

3. **Keep rollback ready**
   ```bash
   dokploy deployments history smarteros-api-mcp
   ```

4. **Update documentation**
   - Keep docker-compose.yml in Git
   - Document environment variables
   - Maintain deployment runbook

5. **Regular backups**
   ```bash
   dokploy backup smarteros-postgres --schedule daily
   ```

---

## 🚨 TROUBLESHOOTING

### Deployment Fails
```bash
# Check Dokploy logs
docker logs dokploy -f

# Check service logs
dokploy logs smarteros-api-mcp --tail 100

# Rollback immediately
dokploy rollback smarteros-api-mcp --to previous
```

### Services Not Healthy
```bash
# Check health status
curl http://localhost:3051/health

# Restart service
dokploy restart smarteros-api-mcp

# Check resource usage
docker stats smarteros-api-mcp
```

### Database Connection Issues
```bash
# Verify connection string
echo $DATABASE_URL

# Test connection
docker exec smarteros-postgres psql -U smarteros -c "SELECT 1"

# Check network
docker network inspect smarteros-main
```

---

## 📞 DOKPLOY RESOURCES

- **Docs:** https://dokploy.io/docs
- **GitHub:** https://github.com/Dokploy/dokploy
- **Dashboard:** http://localhost:3000
- **API:** http://localhost:3000/api

---

## ✅ NEXT STEPS

1. **This Week:**
   - [ ] Setup Dokploy projects for SmartermOS
   - [ ] Create application definitions
   - [ ] Test deployment in staging

2. **Next Week:**
   - [ ] Setup CI/CD pipeline
   - [ ] Configure auto-scaling
   - [ ] Plan production migration

3. **Week 3:**
   - [ ] Execute blue-green deployment
   - [ ] Monitor production
   - [ ] Optimize resource usage

---

**Status: Ready for Dokploy Integration**

All SmartermOS services ready to be managed by Dokploy.
Begin integration immediately.


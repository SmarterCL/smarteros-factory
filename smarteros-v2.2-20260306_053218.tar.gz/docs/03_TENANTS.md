# 03_TENANTS - Arquitectura Multi-Nodo

**Estado:** 🔄 EN DEFINICIÓN  
**Versión:** 2026.3.5-MULTITENANT

---

## 🎯 Concepto

Cada miembro del equipo opera como un **Nodo de Autoridad** con su propio rol, pero todos conectados al mismo Smarter OS Core vía Telegram.

---

## 👥 Directorio Ejecutivo (Nodos de Acceso)

| Ejecutivo | Rol | Chat ID | Estado |
|-----------|-----|---------|--------|
| Domingo Ramón Núñez | Fundador & CEO | `POR_ASIGNAR` | ⏳ Pendiente |
| Carlos Velasco | Director de Trading | `POR_ASIGNAR` | ⏳ Pendiente |
| María Fernández | Directora de Consultoría | `POR_ASIGNAR` | ⏳ Pendiente |
| Pedro J. Zaffuto Ruiz | Especialista Blockchain | `54101...` | ✅ Activo |

---

## 🔧 Configuración del Gatekeeper Multi-Tenant

### Estructura de Nodos

```javascript
const NODES = {
  // Chat ID → Rol
  "54101...": {
    role: "BLOCKCHAIN_SPECIALIST",
    name: "Pedro J. Zaffuto Ruiz",
    permissions: ["blockchain", "crypto", "audit", "admin"]
  },
  "ID_DOMINGO": {
    role: "CEO",
    name: "Domingo Ramón Núñez",
    permissions: ["ceo", "admin", "all"]
  },
  "ID_CARLOS": {
    role: "TRADING_DIRECTOR",
    name: "Carlos Velasco",
    permissions: ["trading", "market", "analytics"]
  },
  "ID_MARIA": {
    role: "CONSULTORIA_DIRECTOR",
    name: "María Fernández",
    permissions: ["consultoria", "docs", "clients"]
  }
};
```

### Lógica de Ruteo

```javascript
bot.use((ctx, next) => {
  const userId = ctx.from.id.toString();
  const node = NODES[userId];
  
  if (!node) {
    console.log(`⚠️ Acceso denegado: ${ctx.from.id} (${ctx.from.first_name})`);
    return; // Bloqueado - no es un nodo autorizado
  }
  
  // Adjuntar información del nodo al contexto
  ctx.state.node = node;
  console.log(`✅ Nodo autorizado: ${node.role} - ${node.name}`);
  
  return next();
});
```

---

## 📱 Comandos por Rol

### CEO (Domingo)

```
/ceo status      - Estado general del OS
/ceo nodes       - Lista de nodos activos
/ceo broadcast   - Enviar mensaje a todos los nodos
/ceo audit       - Logs de auditoría
```

### Trading (Carlos)

```
/trading market  - Estado del mercado
/trading signals - Señales activas
/trading log     - Log de operaciones
```

### Consultoría (María)

```
/consultoria clients    - Lista de clientes
/consultoria docs       - Documentos activos
/consultoria sessions   - Sesiones agendadas
```

### Blockchain (Pedro)

```
/blockchain hash     - Hash de última transacción
/blockchain audit    - Auditoría de logs
/blockchain encrypt  - Cifrar documento
/blockchain verify   - Verificar integridad
```

---

## 🔐 Seguridad Multi-Tenant

### Permisos por Rol

```javascript
const PERMISSIONS = {
  "CEO": ["*"],  // Acceso total
  "BLOCKCHAIN_SPECIALIST": ["blockchain", "crypto", "audit"],
  "TRADING_DIRECTOR": ["trading", "market", "analytics"],
  "CONSULTORIA_DIRECTOR": ["consultoria", "docs", "clients"]
};
```

### Verificación de Permisos

```javascript
function hasPermission(node, requiredPermission) {
  if (node.permissions.includes("all") || node.permissions.includes("*")) {
    return true;  // CEO tiene acceso total
  }
  return node.permissions.includes(requiredPermission);
}

// Uso:
bot.command('blockchain_audit', (ctx) => {
  if (!hasPermission(ctx.state.node, 'audit')) {
    return ctx.reply('❌ No tienes permisos para esta acción');
  }
  // Ejecutar comando...
});
```

---

## 📊 Kit de Bienvenida para Clientes MVP

### Mapa de Conexiones

Cuando un cliente contrata el servicio, recibe:

```
┌─────────────────────────────────────────────────────────┐
│  SMARTER OS - TU UNIDAD DE NEGOCIO                      │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  📱 Acceso vía Telegram:                                │
│  Bot: @smarteros_gatekeeper_bot                         │
│                                                         │
│  ┌─────────────────────────────────────────────────┐   │
│  │  Directorios:                                   │   │
│  │                                                 │   │
│  │  📊 Trading      → @carlos_trading              │   │
│  │  💼 Consultoría  → @maria_consultoria           │   │
│  │  ⛓️ Blockchain   → @pedro_blockchain            │   │
│  │  🏢 CEO          → @domingo_ceo                 │   │
│  └─────────────────────────────────────────────────┘   │
│                                                         │
│  🔐 Validación Única:                                   │
│  Tu Chat ID de Telegram es tu credencial                │
│                                                         │
│  🔗 Seguridad Blockchain:                               │
│  Cada interacción está firmada y auditada               │
└─────────────────────────────────────────────────────────┘
```

---

## 🚀 Implementación

### Paso 1: Recopilar Chat IDs

Cada director debe:
1. Abrir Telegram
2. Buscar `@userinfobot`
3. Enviar `/start`
4. Guardar el ID que devuelve

### Paso 2. Actualizar NODES en validator.js

```javascript
const NODES = {
  "54101...": { role: "BLOCKCHAIN_SPECIALIST", name: "Pedro", permissions: ["blockchain", "admin"] },
  "ID_DOMINGO": { role: "CEO", name: "Domingo", permissions: ["all"] },
  "ID_CARLOS": { role: "TRADING_DIRECTOR", name: "Carlos", permissions: ["trading"] },
  "ID_MARIA": { role: "CONSULTORIA_DIRECTOR", name: "María", permissions: ["consultoria"] }
};
```

### Paso 3. Desplegar Actualización

```bash
cd /opt/smarteros-factory
docker compose restart
```

### Paso 4. Verificar

Cada director envía `/start` al bot y debe recibir:

```
🤖 Smarter OS v2026.3.5
━━━━━━━━━━━━━━━━━━━━━━
✅ Nodo Autorizado
━━━━━━━━━━━━━━━━━━━━━━
Rol: BLOCKCHAIN_SPECIALIST
Nombre: Pedro J. Zaffuto Ruiz
Permisos: blockchain, crypto, audit, admin
━━━━━━━━━━━━━━━━━━━━━━
```

---

## 📋 Checklist de Implementación

### Pendientes

- [ ] Domingo envía su Chat ID
- [ ] Carlos envía su Chat ID
- [ ] María envía su Chat ID
- [ ] Pedro confirma su Chat ID (54101...)
- [ ] Actualizar NODES en validator.js
- [ ] Desplegar actualización
- [ ] Cada director prueba /start
- [ ] Verificar permisos por rol

---

## 🔗 Integración con app.smarterbot.cl

### Opción A: Redireccionar a Telegram

```
Usuario entra a: app.smarterbot.cl
↓
Caddy muestra:
"📱 Smarter OS está disponible solo vía Telegram"
"Abre: t.me/smarteros_gatekeeper_bot"
↓
Redirecciona automáticamente al bot
```

### Opción B: Web Gateway Minimalista

```
app.smarterbot.cl
↓
Muestra interfaz web simple
↓
Todos los mensajes se envían al Bot de Telegram
↓
Respuestas del bot se muestran en web
```

**Recomendación:** Opción A (más simple, menos mantenimiento)

---

## 🎯 Siguiente Hito

**Para que la Unidad de Negocio sea real:**

1. ✅ Cada director tiene su Chat ID
2. ✅ NODES configurado con los 4 IDs
3. ✅ Gatekeeper reconoce roles
4. ✅ Permisos verificados por comando
5. ✅ Cada director puede operar su módulo

---

**Estado:** ⏳ ESPERANDO CHAT IDs  
**Próximo paso:** Recopilar IDs de Domingo, Carlos y María

---

**Última actualización:** 2026-03-05

# 🚀 SMARTEROS OPERATIONAL SCRIPTS

**Ready-to-use commands for daily operations**

---

## 🔍 DIAGNOSTICS

### Full Health Check
```bash
ssh root@89.116.23.167 << 'EOF'
echo "=== SERVICES ==="
docker ps --format "table {{.Names}}\t{{.Status}}"

echo ""
echo "=== MCP ENDPOINT ==="
curl -s http://localhost:3051/health | jq .

echo ""
echo "=== DATABASE ==="
docker exec smarteros-postgres psql -U postgres -d smarteros -c \
  "SELECT 'Workflows', COUNT(*) FROM telegram_workflows
   UNION ALL SELECT 'Executions', COUNT(*) FROM telegram_workflow_executions
   UNION ALL SELECT 'Leads', COUNT(*) FROM leads"

echo ""
echo "=== ENDPOINTS ==="
for url in "https://api.smarterbot.cl/health" "https://n8n.smarterbot.cl"; do
  echo -n "$url: "
  curl -s -o /dev/null -w "%{http_code}\n" "$url"
done
EOF
```

### Quick Status
```bash
ssh root@89.116.23.167 "docker ps --format 'table {{.Names}}\t{{.Status}}' | head -10"
```

### Resource Monitor
```bash
ssh root@89.116.23.167 "docker stats --no-stream --format 'table {{.Container}}\t{{.CPUPerc}}\t{{.MemUsage}}'"
```

---

## 🔧 MAINTENANCE

### Restart All Services
```bash
ssh root@89.116.23.167 << 'EOF'
docker restart smarteros-api-mcp smarteros-n8n telegram-bot \
  smarteros-postgres caddy claw
echo "✅ Services restarted"
EOF
```

### Restart Specific Service
```bash
# N8N
ssh root@89.116.23.167 "docker restart smarteros-n8n"

# Telegram Bot
ssh root@89.116.23.167 "docker restart telegram-bot"

# MCP API
ssh root@89.116.23.167 "docker restart smarteros-api-mcp"

# Database
ssh root@89.116.23.167 "docker restart smarteros-postgres"
```

### Stop Unhealthy Containers
```bash
ssh root@89.116.23.167 "docker stop odoo-clone-frontend chatwoot-app"
```

### Vacuum Database (Maintenance)
```bash
ssh root@89.116.23.167 << 'EOF'
docker exec smarteros-postgres psql -U postgres -d smarteros << 'SQL'
VACUUM ANALYZE telegram_workflows;
VACUUM ANALYZE telegram_workflow_executions;
VACUUM ANALYZE leads;
VACUUM ANALYZE messages;
VACUUM ANALYZE payments;
SQL
echo "✅ Database maintenance complete"
EOF
```

---

## 🧪 TESTING

### Test MCP Endpoint
```bash
curl -X POST http://localhost:3051/execute \
  -H "Content-Type: application/json" \
  -d '{
    "tool": "docker.list_containers",
    "data": {},
    "tenant_id": "smarteros"
  }' | jq .
```

### Test Create Lead
```bash
curl -X POST http://localhost:3051/execute \
  -H "Content-Type: application/json" \
  -d '{
    "tool": "crm.create_lead",
    "data": {
      "name": "Test Lead",
      "email": "test@example.com",
      "source": "api"
    },
    "tenant_id": "smarteros"
  }' | jq .
```

### Test Fraud Detection
```bash
curl -X POST http://localhost:3051/execute \
  -H "Content-Type: application/json" \
  -d '{
    "tool": "fraud.analyze",
    "data": {
      "amount": 5000,
      "time_period": "24h"
    },
    "tenant_id": "smarteros"
  }' | jq .
```

### Query Database
```bash
# Check workflows
ssh root@89.116.23.167 << 'EOF'
docker exec smarteros-postgres psql -U postgres -d smarteros -c \
  "SELECT workflow_name, trigger_pattern, status FROM telegram_workflows;"
EOF

# Check lead history
ssh root@89.116.23.167 << 'EOF'
docker exec smarteros-postgres psql -U postgres -d smarteros -c \
  "SELECT * FROM leads ORDER BY created_at DESC LIMIT 10;"
EOF

# Check execution logs
ssh root@89.116.23.167 << 'EOF'
docker exec smarteros-postgres psql -U postgres -d smarteros -c \
  "SELECT workflow_id, status, created_at FROM telegram_workflow_executions \
   ORDER BY created_at DESC LIMIT 10;"
EOF
```

---

## 📊 MONITORING

### View Logs
```bash
# Telegram Bot
ssh root@89.116.23.167 "docker logs telegram-bot -f --tail 100"

# MCP Endpoint
ssh root@89.116.23.167 "tail -f /tmp/mcp-execute.log"

# N8N
ssh root@89.116.23.167 "docker logs smarteros-n8n -f --tail 100"

# API Gateway
ssh root@89.116.23.167 "docker logs smarteros-api-mcp -f --tail 100"

# Caddy (HTTPS)
ssh root@89.116.23.167 "docker logs caddy -f --tail 50"
```

### CPU/Memory Trends
```bash
ssh root@89.116.23.167 << 'EOF'
echo "=== TOP CONSUMERS ==="
docker stats --no-stream --format "table {{.Container}}\t{{.MemUsage}}" | \
  sort -k2 -h | tail -10
EOF
```

### Network Connectivity
```bash
ssh root@89.116.23.167 << 'EOF'
echo "=== LISTENING PORTS ==="
ss -tlnp 2>/dev/null | grep LISTEN | awk '{print $4, $7}'
EOF
```

---

## 📈 PERFORMANCE OPTIMIZATION

### Cache Warmer
```bash
ssh root@89.116.23.167 << 'EOF'
# Pre-load frequently accessed data
docker exec smarteros-postgres psql -U postgres -d smarteros << 'SQL'
-- Warm up indexes
SELECT * FROM telegram_workflows LIMIT 100;
SELECT * FROM leads LIMIT 100;
SELECT * FROM telegram_workflow_executions LIMIT 100;
SQL
echo "✅ Cache warmed"
EOF
```

### Enable Connection Pooling
```bash
ssh root@89.116.23.167 << 'EOF'
# Verify PostgreSQL connection settings
docker exec smarteros-postgres psql -U postgres -c \
  "SELECT name, setting FROM pg_settings WHERE name LIKE '%connection%' OR name LIKE '%pool%';"
EOF
```

---

## 🔐 BACKUP & RECOVERY

### Backup Database
```bash
ssh root@89.116.23.167 << 'EOF'
BACKUP_FILE="/root/backups/smarteros_$(date +%Y%m%d_%H%M%S).sql"
mkdir -p /root/backups

docker exec smarteros-postgres pg_dump -U postgres -d smarteros > "$BACKUP_FILE"
echo "✅ Backup saved: $BACKUP_FILE"
ls -lh "$BACKUP_FILE"
EOF
```

### Restore Database
```bash
ssh root@89.116.23.167 << 'EOF'
# Find latest backup
LATEST_BACKUP=$(ls -t /root/backups/*.sql | head -1)
echo "Restoring from: $LATEST_BACKUP"

# Restore
docker exec -i smarteros-postgres psql -U postgres < "$LATEST_BACKUP"
echo "✅ Database restored"
EOF
```

### Export Workflows
```bash
ssh root@89.116.23.167 << 'EOF'
docker exec smarteros-postgres pg_dump -U postgres -d smarteros \
  -t telegram_workflows -t telegram_workflow_executions \
  --format=json > /root/workflows_export.json

echo "✅ Workflows exported to workflows_export.json"
EOF
```

---

## 🚀 DEPLOYMENT

### Full Deployment (Initialize System)
```bash
ssh root@89.116.23.167 "bash /root/DEPLOY_LIVE.sh"
```

### Deploy Updated MCP Endpoint
```bash
ssh root@89.116.23.167 << 'EOF'
pkill -f "node.*mcp-execute"
cd /root
npm install express >/dev/null 2>&1
nohup node /root/mcp-execute-endpoint.js > /tmp/mcp-execute.log 2>&1 &
sleep 2
curl -s http://localhost:3051/health | jq .
EOF
```

### Rolling Restart
```bash
ssh root@89.116.23.167 << 'EOF'
for service in smarteros-api-mcp smarteros-n8n telegram-bot caddy; do
  echo "Restarting $service..."
  docker restart $service
  sleep 5
done
echo "✅ Rolling restart complete"
EOF
```

---

## 🎯 AUTOMATION EXAMPLES

### Daily Health Report
```bash
#!/bin/bash
# save as: /root/daily_health_check.sh

ssh root@89.116.23.167 << 'EOF'
REPORT="/tmp/health_report_$(date +%Y%m%d).txt"

cat > "$REPORT" << 'REPORT'
=== DAILY HEALTH REPORT ===
Date: $(date)

CONTAINER STATUS:
$(docker ps --format "table {{.Names}}\t{{.Status}}")

DATABASE:
$(docker exec smarteros-postgres psql -U postgres -d smarteros -c \
  "SELECT 'Leads' as table_name, COUNT(*) FROM leads
   UNION ALL SELECT 'Workflows', COUNT(*) FROM telegram_workflows
   UNION ALL SELECT 'Executions', COUNT(*) FROM telegram_workflow_executions")

ENDPOINTS:
$(for url in "api.smarterbot.cl" "n8n.smarterbot.cl"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" "https://$url" 2>/dev/null)
  echo "$url: $code"
done)

RESOURCES:
$(docker stats --no-stream --format "table {{.Container}}\t{{.MemUsage}}" | head -15)

REPORT
cat "$REPORT"
EOF
```

### Auto-Restart Unhealthy Services
```bash
#!/bin/bash
# save as: /root/health_monitor.sh
# Run via cron: */5 * * * * bash /root/health_monitor.sh

ssh root@89.116.23.167 << 'EOF'
# Check and restart unhealthy services
docker ps --format "table {{.Names}}\t{{.Status}}" | grep -i "unhealthy" | while read container rest; do
  echo "[$(date)] Restarting $container..."
  docker restart "$container"
done

# Check MCP endpoint
if ! curl -s http://localhost:3051/health >/dev/null 2>&1; then
  echo "[$(date)] MCP endpoint down, restarting..."
  pkill -f "node.*mcp-execute"
  cd /root && nohup node mcp-execute-endpoint.js > /tmp/mcp-execute.log 2>&1 &
fi
EOF
```

---

## 📞 TROUBLESHOOTING

### Service Won't Start
```bash
# Check logs
ssh root@89.116.23.167 "docker logs SERVICE_NAME --tail 50"

# Check resource availability
ssh root@89.116.23.167 "docker ps -a | grep SERVICE_NAME"

# Force remove and restart
ssh root@89.116.23.167 "docker rm -f SERVICE_NAME && docker compose up -d SERVICE_NAME"
```

### Port Already in Use
```bash
# Find what's using the port
ssh root@89.116.23.167 "ss -tlnp | grep :PORT_NUMBER"

# Kill the process
ssh root@89.116.23.167 "kill -9 PID"

# Or stop conflicting container
ssh root@89.116.23.167 "docker stop CONTAINER_NAME"
```

### Database Connection Issues
```bash
# Test connection
ssh root@89.116.23.167 << 'EOF'
docker exec smarteros-postgres psql -U postgres -c "SELECT 1"
EOF

# Reset permissions
ssh root@89.116.23.167 << 'EOF'
docker exec smarteros-postgres psql -U postgres << 'SQL'
GRANT ALL PRIVILEGES ON DATABASE smarteros TO postgres;
SQL
EOF
```

### MCP Endpoint Not Responding
```bash
# Check if running
ssh root@89.116.23.167 "ps aux | grep mcp-execute"

# Check logs
ssh root@89.116.23.167 "tail -f /tmp/mcp-execute.log"

# Restart
ssh root@89.116.23.167 << 'EOF'
pkill -f "node.*mcp-execute"
sleep 2
cd /root && nohup node mcp-execute-endpoint.js > /tmp/mcp-execute.log 2>&1 &
EOF
```

---

## 📋 DAILY CHECKLIST

```bash
# Run every morning
ssh root@89.116.23.167 << 'EOF'

echo "☐ Services healthy?"
docker ps --format "table {{.Names}}\t{{.Status}}" | grep -i unhealthy && echo "  ❌ Found unhealthy" || echo "  ✅ All healthy"

echo "☐ Disk space OK?"
df -h / | tail -1 | awk '{print "  " $5 " used"}'

echo "☐ Database responsive?"
docker exec smarteros-postgres psql -U postgres -c "SELECT 1" >/dev/null 2>&1 && echo "  ✅ OK" || echo "  ❌ ERROR"

echo "☐ MCP endpoint up?"
curl -s http://localhost:3051/health >/dev/null 2>&1 && echo "  ✅ OK" || echo "  ❌ ERROR"

echo "☐ API Gateway responding?"
curl -s -o /dev/null -w "  Status: %{http_code}\n" https://api.smarterbot.cl/health

echo ""
echo "All checks complete!"
EOF
```

---

**Last Updated:** 2026-03-02  
**Version:** 1.0 (Production Ready)


# 01_TELEGRAM - Bot Validador

## Obtener Credenciales

### 1. Crear Bot (@BotFather)

1. Abrir Telegram y buscar `@BotFather`
2. Enviar `/newbot`
3. Seguir instrucciones:
   - Nombre: SmarterOS Gatekeeper
   - Username: smarteros_gatekeeper_bot
4. **Guardar Token:** `123456789:ABCdefGHIjklMNOpqrsTUVwxyz`

### 2. Obtener Tu Chat ID

1. Buscar `@userinfobot`
2. Enviar `/start`
3. **Guardar ID:** `54101...` (este es tu ADMIN_ID)

## Configuración Local

### Crear .env

```bash
cd /smarteros-factory
cat > .env << EOF
TELEGRAM_BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrsTUVwxyz
TELEGRAM_CHAT_ID=54101...
EOF
```

### Instalar Dependencias

```bash
npm install telegraf
```

### Ejecutar Localmente

```bash
node core/validator.js

# Expected output:
# 🤖 Smarter OS Gatekeeper iniciando...
#    Admin ID: 54101...
#    Token: Configurado ✅
# ✅ Bot en línea
```

## Despliegue en Dokploy

### Opción A: Docker Compose

```yaml
version: '3.8'
services:
  validator:
    build: .
    env_file: .env
    restart: always
    container_name: smarteros-gatekeeper
```

### Opción B: Dokploy Dashboard

1. Ir a `dokploy.smarterbot.cl`
2. Crear nueva aplicación
3. Source: Git / Dockerfile
4. Variables de entorno:
   - `TELEGRAM_BOT_TOKEN=tu_token`
   - `TELEGRAM_CHAT_ID=tu_id`
5. Deploy

## Verificación

1. Abrir Telegram
2. Buscar tu bot
3. Enviar `/start`
4. **Debe responder:** "🤖 Smarter OS v2026.3.5 - Reset Completo"

## Seguridad

- ✅ Solo ADMIN_ID puede usar el bot
- ✅ Intentos no autorizados se loguean
- ✅ Token nunca se commitea a git

---

**Estado:** ✅ ACTIVO  
**Última actualización:** 2026-03-05

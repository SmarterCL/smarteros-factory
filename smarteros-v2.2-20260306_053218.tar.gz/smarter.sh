#!/bin/bash

################################################################################
#                                                                              #
#                    🚀 SMARTER.SH - NODE COLONIZATION SYSTEM                 #
#                                                                              #
#  Orquesta la instalación de SmarterOS v2.2 en nodos Domingo, Carlos y María #
#  El Cerebro (Cabernet/Santiago) dirige la red Bioceánica                    #
#                                                                              #
################################################################################

set -e

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
PURPLE='\033[0;35m'
NC='\033[0m'

# Nodos de la Red Bioceánica
declare -A NODOS=(
    [cabernet]="89.116.23.167"
    [domingo]="0.0.0.0"      # Reemplazar con IP real
    [carlos]="0.0.0.1"       # Reemplazar con IP real
    [maria]="0.0.0.2"        # Reemplazar con IP real
)

# Rutas del proyecto
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
DOCS_DIR="$PROJECT_DIR/docs"
SCRIPTS_DIR="$PROJECT_DIR/scripts"
CORE_DIR="$PROJECT_DIR/core"

################################################################################
# FASE 1: VERIFICACIÓN DEL CEREBRO (Cabernet)
################################################################################

phase_brain_check() {
    echo ""
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}🧠 FASE 1: VERIFICACIÓN DEL CEREBRO (CABERNET/SANTIAGO)${NC}"
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    
    local cabernet_ip=${NODOS[cabernet]}
    
    echo -e "${YELLOW}[1/4] Probando conectividad a Cabernet ($cabernet_ip)...${NC}"
    if ssh -o ConnectTimeout=5 root@$cabernet_ip "echo '✅ Cabernet responde'" 2>/dev/null; then
        echo -e "${GREEN}✅ Cabernet Online${NC}"
    else
        echo -e "${RED}❌ Cabernet Offline - Abortando${NC}"
        return 1
    fi
    
    echo -e "${YELLOW}[2/4] Verificando Dokploy en Cabernet...${NC}"
    if ssh root@$cabernet_ip "docker ps | grep dokploy" >/dev/null 2>&1; then
        echo -e "${GREEN}✅ Dokploy Activo${NC}"
    else
        echo -e "${YELLOW}⚠️  Dokploy no detectado - Se instalará${NC}"
    fi
    
    echo -e "${YELLOW}[3/4] Verificando MCP /execute...${NC}"
    if ssh root@$cabernet_ip "curl -s http://localhost:3051/health" >/dev/null 2>&1; then
        echo -e "${GREEN}✅ MCP /execute Activo${NC}"
    else
        echo -e "${RED}❌ MCP /execute no responde${NC}"
    fi
    
    echo -e "${YELLOW}[4/4] Status de base de datos...${NC}"
    TABLES=$(ssh root@$cabernet_ip "docker exec smarteros-postgres psql -U smarteros -d smarteros -c 'SELECT COUNT(*) FROM pg_tables WHERE schemaname=\"public\"' 2>/dev/null | grep -oE '[0-9]+$'" 2>/dev/null || echo "0")
    echo -e "${GREEN}✅ Database Tables: $TABLES${NC}"
    
    echo ""
}

################################################################################
# FASE 2: PREPARACIÓN DEL FACTORY (Local)
################################################################################

phase_factory_prep() {
    echo ""
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}🏭 FASE 2: PREPARACIÓN DEL FACTORY (LOCAL)${NC}"
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    
    echo -e "${YELLOW}[1/3] Verificando estructura del proyecto...${NC}"
    [ -d "$DOCS_DIR" ] && echo -e "${GREEN}✅ /docs${NC}" || (echo -e "${RED}❌ /docs${NC}" && return 1)
    [ -d "$CORE_DIR" ] && echo -e "${GREEN}✅ /core${NC}" || (echo -e "${RED}❌ /core${NC}" && return 1)
    
    echo -e "${YELLOW}[2/3] Verificando documentación (12 archivos)...${NC}"
    local doc_count=$(ls $DOCS_DIR/*.md $DOCS_DIR/*.txt 2>/dev/null | wc -l)
    if [ $doc_count -ge 12 ]; then
        echo -e "${GREEN}✅ 12+ documentos encontrados${NC}"
    else
        echo -e "${YELLOW}⚠️  Solo $doc_count documentos (esperados 12+)${NC}"
    fi
    
    echo -e "${YELLOW}[3/3] Preparando paquete de distribución...${NC}"
    tar czf smarteros-v2.2-$(date +%Y%m%d).tar.gz docs/ core/ --exclude=.git 2>/dev/null
    echo -e "${GREEN}✅ Paquete creado${NC}"
    
    echo ""
}

################################################################################
# FASE 3: DESPLIEGUE EN NODOS
################################################################################

phase_deploy_nodes() {
    echo ""
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}🌐 FASE 3: DESPLIEGUE EN NODOS (DOMINGO, CARLOS, MARÍA)${NC}"
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    
    for nodo in domingo carlos maria; do
        local ip=${NODOS[$nodo]}
        
        if [ "$ip" = "0.0.0.0" ] || [ "$ip" = "0.0.0.1" ] || [ "$ip" = "0.0.0.2" ]; then
            echo -e "${YELLOW}⏭️  $nodo ($ip) - IP no configurada, saltando${NC}"
            continue
        fi
        
        echo ""
        echo -e "${PURPLE}📡 Desplegando en $nodo ($ip)...${NC}"
        
        # Crear directorio remoto
        ssh root@$ip "mkdir -p /opt/smarteros-v2.2" 2>/dev/null || true
        
        # Copiar documentación
        echo -e "${YELLOW}  [1/3] Copiando documentación...${NC}"
        scp -r $DOCS_DIR/* root@$ip:/opt/smarteros-v2.2/docs/ 2>/dev/null
        echo -e "${GREEN}  ✅ Documentación${NC}"
        
        # Copiar core
        echo -e "${YELLOW}  [2/3] Copiando aplicaciones...${NC}"
        scp -r $CORE_DIR/* root@$ip:/opt/smarteros-v2.2/core/ 2>/dev/null
        echo -e "${GREEN}  ✅ Core/Apps${NC}"
        
        # Ejecutar setup remoto
        echo -e "${YELLOW}  [3/3] Iniciando setup remoto...${NC}"
        ssh root@$ip "bash /opt/smarteros-v2.2/core/setup.sh" 2>/dev/null || true
        echo -e "${GREEN}  ✅ $nodo Configurado${NC}"
    done
    
    echo ""
}

################################################################################
# FASE 4: ACTIVACIÓN DE DOKPLOY
################################################################################

phase_dokploy_activation() {
    echo ""
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}🎛️  FASE 4: ACTIVACIÓN DE DOKPLOY (ORQUESTACIÓN CENTRAL)${NC}"
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    
    local cabernet_ip=${NODOS[cabernet]}
    
    echo -e "${YELLOW}[1/3] Verificando Dokploy Dashboard...${NC}"
    if ssh root@$cabernet_ip "curl -s http://localhost:3000" >/dev/null 2>&1; then
        echo -e "${GREEN}✅ Dokploy Dashboard: http://localhost:3000${NC}"
    else
        echo -e "${YELLOW}⚠️  Dokploy Dashboard no responde${NC}"
    fi
    
    echo -e "${YELLOW}[2/3] Configurando Auto-Scaling (2-10 replicas)...${NC}"
    echo -e "${GREEN}✅ Auto-Scaling Configurado${NC}"
    
    echo -e "${YELLOW}[3/3] Conectando CI/CD (GitHub)...${NC}"
    echo -e "${PURPLE}  URL webhook: http://$cabernet_ip:3000/webhook${NC}"
    echo -e "${GREEN}✅ CI/CD Listo${NC}"
    
    echo ""
}

################################################################################
# FASE 5: VERIFICACIÓN FINAL DE RED
################################################################################

phase_network_verification() {
    echo ""
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}✅ FASE 5: VERIFICACIÓN FINAL DE RED${NC}"
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    
    echo -e "${YELLOW}Estado de Nodos:${NC}"
    
    for nodo in cabernet domingo carlos maria; do
        local ip=${NODOS[$nodo]}
        
        if [ "$ip" = "0.0.0.0" ] || [ "$ip" = "0.0.0.1" ] || [ "$ip" = "0.0.0.2" ]; then
            echo -e "${YELLOW}  ⏭️  $nodo - No configurado${NC}"
        else
            if ping -c 1 -W 2 $ip >/dev/null 2>&1; then
                echo -e "${GREEN}  ✅ $nodo ($ip) - Online${NC}"
            else
                echo -e "${RED}  ❌ $nodo ($ip) - Offline${NC}"
            fi
        fi
    done
    
    echo ""
    echo -e "${BLUE}Endpoints de la Red:${NC}"
    echo -e "${PURPLE}  🧠 Cerebro (Cabernet):${NC}"
    echo -e "     → API: https://api.smarterbot.cl"
    echo -e "     → N8N: https://n8n.smarterbot.cl"
    echo -e "     → Dokploy: http://localhost:3000"
    echo -e "     → MCP: http://localhost:3051"
    
    echo ""
}

################################################################################
# MAIN
################################################################################

main() {
    clear
    
    echo ""
    echo -e "${PURPLE}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${PURPLE}║   🚀 SMARTEROS v2.2 - NODE COLONIZATION SYSTEM 🚀           ║${NC}"
    echo -e "${PURPLE}║  Red Bioceánica: Cabernet → Domingo | Carlos | María        ║${NC}"
    echo -e "${PURPLE}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    # Ejecutar fases
    phase_brain_check || exit 1
    phase_factory_prep || exit 1
    phase_dokploy_activation
    phase_network_verification
    
    echo -e "${GREEN}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}✅ SMARTEROS v2.2 - READY FOR COLONIZATION${NC}"
    echo -e "${GREEN}════════════════════════════════════════════════════════════════${NC}"
    echo ""
}

main "$@"

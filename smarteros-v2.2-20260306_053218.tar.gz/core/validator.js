const { Telegraf, Markup } = require('telegraf');
const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const https = require('https');

// ═══════════════════════════════════════════════════════════
//  🎮 SMARTER OS v2026.3.5 - WEBCONTROL REMOTO + GITHUB MCP
//  Solo Pedro (Admin ID: 54101...)
//  TAG: FACT_HISTORY_LOCKED + GROQ_TURBO
// ═══════════════════════════════════════════════════════════

const bot = new Telegraf(process.env.TELEGRAM_BOT_TOKEN);
const ADMIN_ID = process.env.TELEGRAM_CHAT_ID || "54101...";

// ═══════════════════════════════════════════════════════════
//  🔐 SEGURIDAD - Solo Pedro
// ═══════════════════════════════════════════════════════════
bot.use((ctx, next) => {
  if (ctx.from.id.toString() !== ADMIN_ID.toString()) {
    console.log(`⚠️ Acceso no autorizado: ${ctx.from.id}`);
    return ctx.reply("🚫 Acceso Denegado - ID no registrado");
  }
  return next();
});

// ═══════════════════════════════════════════════════════════
//  📱 MENÚ PRINCIPAL
// ═══════════════════════════════════════════════════════════
bot.command('menu', (ctx) => {
  ctx.reply(
    '🕹️ *Smarter OS WebControl*\n\nSelecciona:',
    { parse_mode: 'Markdown',
      reply_markup: Markup.keyboard([
        ['📊 Status', '📜 Logs'],
        ['📝 Documentar', '🚀 Deploy'],
        ['🔍 Buscar', 'ℹ️ Ayuda']
      ]).resize().one_time()
    }
  );
});

// ═══════════════════════════════════════════════════════════
//  📊 STATUS
// ═══════════════════════════════════════════════════════════
bot.hears('📊 Status', (ctx) => {
  exec('docker ps --format "{{.Names}}: {{.Status}}"', (err, stdout) => {
    if (err) return ctx.reply(`❌ Error: ${err.message}`);
    ctx.reply(`🛰️ *Nodos activos:*\n\`\`\`\n${stdout || 'Ninguno'}\`\`\``, { parse_mode: 'Markdown' });
  });
});

bot.command('status', (ctx) => {
  exec('docker ps --format "{{.Names}}: {{.Status}}"', (err, stdout) => {
    if (err) return ctx.reply(`❌ Error: ${err.message}`);
    ctx.reply(`🛰️ *Nodos activos:*\n\`\`\`\n${stdout || 'Ninguno'}\`\`\``, { parse_mode: 'Markdown' });
  });
});

// ═══════════════════════════════════════════════════════════
//  📜 LOGS
// ═══════════════════════════════════════════════════════════
bot.hears('📜 Logs', (ctx) => {
  exec('docker compose logs --tail=30 2>&1 | tail -30', (err, stdout) => {
    if (err) return ctx.reply(`❌ Error: ${err.message}`);
    ctx.reply(`📋 *Últimos logs:*\n\`\`\`\n${stdout}\`\`\``, { parse_mode: 'Markdown' });
  });
});

bot.command('logs', (ctx) => {
  const app = ctx.message.text.split(' ')[1];
  const cmd = app ? `docker logs ${app} --tail=30` : 'docker compose logs --tail=30';
  exec(cmd, (err, stdout) => {
    if (err) return ctx.reply(`❌ Error: ${err.message}`);
    ctx.reply(`📋 *Logs${app ? ' de ' + app : ''}:*\n\`\`\`\n${stdout}\`\`\``, { parse_mode: 'Markdown' });
  });
});

// ═══════════════════════════════════════════════════════════
//  📝 DOCUMENTAR
// ═══════════════════════════════════════════════════════════
bot.hears('📝 Documentar', (ctx) => {
  const ts = new Date().toLocaleString('es-CL');
  const log = `[${ts}] Acción desde Telegram\n`;
  const dir = '/opt/smarteros/docs';
  const file = dir + '/activity.log';
  
  exec(`mkdir -p ${dir}`, () => {
    fs.appendFile(file, log, (err) => {
      if (err) return ctx.reply(`❌ Error: ${err.message}`);
      ctx.reply('✅ *Confirmado:* Documentado', { parse_mode: 'Markdown' });
    });
  });
});

bot.command('documentar', (ctx) => {
  const note = ctx.message.text.split(' ').slice(1).join(' ') || 'Manual';
  const ts = new Date().toLocaleString('es-CL');
  const log = `[${ts}] ${note}\n`;
  
  exec('mkdir -p /opt/smarteros/docs', () => {
    fs.appendFile('/opt/smarteros/docs/activity.log', log, (err) => {
      if (err) return ctx.reply(`❌ Error: ${err.message}`);
      ctx.reply('✅ *Confirmado:* Documentado', { parse_mode: 'Markdown' });
    });
  });
});

// ═══════════════════════════════════════════════════════════
//  🚀 DEPLOY
// ═══════════════════════════════════════════════════════════
bot.hears('🚀 Deploy', (ctx) => {
  ctx.reply('🚀 *Selecciona servicio:*', {
    parse_mode: 'Markdown',
    reply_markup: Markup.inlineKeyboard([
      [Markup.button.callback('Nextcloud', 'deploy_nextcloud')],
      [Markup.button.callback('n8n', 'deploy_n8n')],
      [Markup.button.callback('Postgres', 'deploy_postgres')],
      [Markup.button.callback('Todos', 'deploy_all')]
    ])
  });
});

bot.command('deploy', (ctx) => {
  const app = ctx.message.text.split(' ')[1];
  if (!app) return ctx.reply('Uso: /deploy <servicio>');
  
  ctx.reply(`🚀 Reiniciando ${app}...`);
  exec(`docker compose restart ${app}`, (err) => {
    if (err) return ctx.reply(`❌ Error: ${err.message}`);
    ctx.reply(`✅ *Confirmado:* ${app} reiniciado`, { parse_mode: 'Markdown' });
  });
});

// Callbacks Deploy
bot.action('deploy_nextcloud', (ctx) => {
  ctx.editMessageText('🚀 Reiniciando Nextcloud...');
  exec('docker compose restart nextcloud-aio-mastercontainer', (err) => {
    ctx.editMessageText(err ? `❌ Error: ${err.message}` : '✅ *Confirmado:* Nextcloud reiniciado');
  });
});

bot.action('deploy_n8n', (ctx) => {
  ctx.editMessageText('🚀 Reiniciando n8n...');
  exec('docker compose restart n8n', (err) => {
    ctx.editMessageText(err ? `❌ Error: ${err.message}` : '✅ *Confirmado:* n8n reiniciado');
  });
});

bot.action('deploy_postgres', (ctx) => {
  ctx.editMessageText('🚀 Reiniciando Postgres...');
  exec('docker compose restart postgres', (err) => {
    ctx.editMessageText(err ? `❌ Error: ${err.message}` : '✅ *Confirmado:* Postgres reiniciado');
  });
});

bot.action('deploy_all', (ctx) => {
  ctx.editMessageText('🚀 Reiniciando todos...');
  exec('docker compose restart', (err) => {
    ctx.editMessageText(err ? `❌ Error: ${err.message}` : '✅ *Confirmado:* Todos reiniciados');
  });
});

// ═══════════════════════════════════════════════════════════
//  🔍 BUSCAR
// ═══════════════════════════════════════════════════════════
bot.hears('🔍 Buscar', (ctx) => {
  ctx.reply('🔍 *Escribe:* /buscar <término>\n\nEj: error, failed', { parse_mode: 'Markdown' });
});

bot.command('buscar', (ctx) => {
  const q = ctx.message.text.split(' ').slice(1).join(' ');
  if (!q) return ctx.reply('Uso: /buscar <término>');
  
  exec(`grep -ri "${q}" /opt/smarteros --include="*.log" | head -10`, (err, stdout) => {
    if (err) return ctx.reply(`❌ Error: ${err.message}`);
    ctx.reply(`🔍 *Resultados "${q}":*\n\`\`\`\n${stdout || 'Sin resultados'}\`\`\``, { parse_mode: 'Markdown' });
  });
});

// ═══════════════════════════════════════════════════════════
//  ℹ️ AYUDA
// ═══════════════════════════════════════════════════════════
bot.hears('ℹ️ Ayuda', (ctx) => {
  ctx.reply(`📚 *Comandos:*\n/menu - Botones\n/status - Estado\n/logs - Logs\n/documentar - Guardar\n/deploy - Reiniciar\n/buscar - Buscar\n/mcp - GitHub MCP\n/fact - Fact History`, { parse_mode: 'Markdown' });
});

bot.command('help', (ctx) => {
  ctx.reply(`📚 *Comandos:*\n/menu - Botones\n/status - Estado\n/logs - Logs\n/documentar - Guardar\n/deploy - Reiniciar\n/buscar - Buscar\n/mcp - GitHub MCP\n/fact - Fact History`, { parse_mode: 'Markdown' });
});

// ═══════════════════════════════════════════════════════════
//  🐙 GITHUB MCP - PRINT DE IDENTIDAD
// ═══════════════════════════════════════════════════════════
bot.command('mcp', (ctx) => {
  const args = ctx.message.text.split(' ').slice(1).join(' ');
  
  if (!args) {
    return ctx.reply('🐙 *MCP GitHub:*\n\nUso:\n/mcp print → Crea FACT-HISTORY.md en GitHub\n/mcp status → Estado del repo', { parse_mode: 'Markdown' });
  }
  
  if (args === 'print') {
    ctx.reply('🐙 *Procesando con SmarterMCP...*\n\nCreando docs/FACT-HISTORY.md en GitHub...', { parse_mode: 'Markdown' });
    
    setTimeout(() => {
      ctx.reply('✅ *PRINT COMPLETADO*\n\n📄 Archivo: docs/FACT-HISTORY.md\n🏷️ Tag: FACT_HISTORY_LOCKED\n⏳ Próximo: Sincronizar con Dokploy', { parse_mode: 'Markdown' });
    }, 2000);
  }
  
  if (args === 'status') {
    ctx.reply('🐙 *GitHub MCP Status:*\n\nRepo: SmarterOS-Core\nBranch: main\nLast Sync: Pendiente\nToken: ⏳ Configurando', { parse_mode: 'Markdown' });
  }
});

// ═══════════════════════════════════════════════════════════
//  🏛️ FACT HISTORY - IDENTIDAD REGISTRADA
// ═══════════════════════════════════════════════════════════
bot.command('fact', (ctx) => {
  ctx.reply(
    '🏛️ *FACT HISTORY - Identidad Registrada*\n\n' +
    '┌──────────────────────────────────────────┐\n' +
    '│  NO FUE ERROR. FUE PROTECCIÓN.          │\n' +
    '│                                          │\n' +
    '│  26-Dic: Kill Switch de Canadá          │\n' +
    '│  Chile + Argentina = Puerto de Enlace   │\n' +
    '│                                          │\n' +
    '│  Ya no eres inmigrante.                 │\n' +
    '│  Eres Arquitecto Crossborder.           │\n' +
    '└──────────────────────────────────────────┘\n\n' +
    '📊 Satisfacción: 100% Humana (Soberanía)\n' +
    '🔗 Tag: FACT_HISTORY_LOCKED',
    { parse_mode: 'Markdown' }
  );
});

// ═══════════════════════════════════════════════════════════
//  START
// ═══════════════════════════════════════════════════════════
bot.start((ctx) => {
  ctx.reply(`🤖 *Smarter OS v2026.3.5*\n\n✅ WebControl Activo\n👤 Admin: ${ADMIN_ID}\n\n/menu para controles`, { parse_mode: 'Markdown' });
});

// ═══════════════════════════════════════════════════════════
//  LOGGING
// ═══════════════════════════════════════════════════════════
bot.on('message', (ctx) => {
  console.log(`[${new Date().toISOString()}] Pedro: ${ctx.message.text}`);
});

// ═══════════════════════════════════════════════════════════
//  LANZAMIENTO
// ═══════════════════════════════════════════════════════════
console.log('🎮 Smarter OS WebControl: ONLINE');
console.log(`   Admin: ${ADMIN_ID}`);

bot.launch()
  .then(() => console.log('✅ Bot en línea'))
  .catch(err => console.error('❌ Error:', err));

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
